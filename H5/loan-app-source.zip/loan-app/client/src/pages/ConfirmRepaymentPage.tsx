/**
 * 确认还款页
 * 设计风格：白色顶部导航，蓝色金额卡片，还款方式，温馨提示（橙色感叹号）
 */
import { useLocation } from "wouter";
import MobileLayout from "@/components/MobileLayout";

export default function ConfirmRepaymentPage() {
  const [, navigate] = useLocation();

  return (
    <MobileLayout>
      {/* 顶部导航 */}
      <div className="sticky top-0 z-10 bg-white border-b border-[#f2f3f5] h-[54px] flex items-center px-5">
        <button onClick={() => navigate("/approval-result")} className="absolute left-5">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none">
            <path d="M15 18L9 12L15 6" stroke="#1d2129" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </button>
        <h1 className="w-full text-center text-[#1d2129] text-[17px] font-semibold">确认还款</h1>
      </div>

      <div className="flex-1 overflow-y-auto bg-[#f7f8fa] pb-24">
        <div className="px-4 pt-4 space-y-3">

          {/* 还款金额卡片 */}
          <div className="bg-gradient-to-br from-[#165dff] via-[#1a65ff] to-[#4d8fff] rounded-2xl p-6 text-center shadow-[0px_8px_24px_rgba(22,93,255,0.25)]">
            <p className="text-white/80 text-[13px] mb-2">还款金额</p>
            <div className="flex items-baseline justify-center gap-1">
              <span className="text-white text-[22px] font-medium">¥</span>
              <span className="text-white text-[48px] font-bold leading-none">1018.50</span>
            </div>
          </div>

          {/* 还款方式 */}
          <div className="bg-white rounded-2xl shadow-sm border border-[#f2f3f5] overflow-hidden">
            <div className="flex justify-between items-center px-5 py-4 border-b border-[#f2f3f5]">
              <span className="text-[#4e5969] text-[15px]">还款方式</span>
              <span className="text-[#165dff] text-[15px] font-medium">提前还款</span>
            </div>
            <button className="w-full flex items-center gap-3 px-5 py-4 active:bg-gray-50 transition-colors">
              <div className="w-10 h-10 bg-[#f0f4ff] rounded-full flex items-center justify-center flex-shrink-0">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <rect x="2" y="5" width="20" height="14" rx="2" stroke="#165DFF" strokeWidth="1.5"/>
                  <path d="M2 10H22" stroke="#165DFF" strokeWidth="1.5"/>
                  <rect x="5" y="13" width="4" height="2" rx="1" fill="#165DFF"/>
                </svg>
              </div>
              <div className="flex-1 text-left">
                <p className="text-[#1d2129] text-[15px] font-semibold">招商银行 (8648)</p>
                <p className="text-[#86909c] text-[13px]">还款银行卡</p>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M9 18L15 12L9 6" stroke="#86909C" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </button>
          </div>

          {/* 温馨提示 */}
          <div className="bg-[#fffbf0] rounded-2xl border border-[#ffe8b8] p-5">
            <div className="flex gap-3">
              <div className="flex-shrink-0 mt-0.5">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <circle cx="12" cy="12" r="10" stroke="#FF9500" strokeWidth="2"/>
                  <path d="M12 8V12" stroke="#FF9500" strokeWidth="2" strokeLinecap="round"/>
                  <circle cx="12" cy="16" r="1" fill="#FF9500"/>
                </svg>
              </div>
              <div>
                <h4 className="text-[#8b4513] text-[13px] font-semibold mb-1">温馨提示</h4>
                <p className="text-[#8b4513] text-[13px] leading-relaxed">
                  还款后将立即生效，剩余期数对应的利息将不再收取。请确认银行卡余额充足。
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* 底部按钮 */}
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[440px] bg-white/95 backdrop-blur-sm px-5 py-4 border-t border-[#f2f3f5]">
        <button
          onClick={() => navigate("/repayment-success")}
          className="w-full h-14 bg-gradient-to-r from-[#165dff] to-[#4d8fff] rounded-full text-white text-[17px] font-semibold shadow-[0px_8px_24px_rgba(22,93,255,0.35)] active:opacity-90 transition-opacity"
        >
          确认支付 ¥1018.50
        </button>
      </div>
    </MobileLayout>
  );
}
