/**
 * 审批结果页 - 审批通过
 * 设计风格：蓝色渐变顶部，三步骤全完成，温馨提示卡片
 * 步骤图标：蓝色圆形，内部白色图标，全部已完成
 */
import { useLocation } from "wouter";
import MobileLayout from "@/components/MobileLayout";

export default function ApprovalResultPage() {
  const [, navigate] = useLocation();

  return (
    <MobileLayout>
      <div className="flex-1 overflow-y-auto bg-[#f7f8fa] pb-24">

        {/* 蓝色渐变顶部 */}
        <div className="bg-gradient-to-b from-[#165dff] to-[#3d7aff] px-5 pt-14 pb-28 overflow-hidden relative">
          <div className="absolute w-48 h-48 right-[-30px] top-[-20px] bg-white/10 rounded-full" />
          <div className="absolute w-36 h-36 left-[-15px] bottom-[-10px] bg-white/10 rounded-full" />
          <div className="relative flex flex-col items-center">
            {/* 成功图标 */}
            <div className="w-[72px] h-[72px] bg-white/25 rounded-full flex items-center justify-center mb-5">
              <svg width="36" height="36" viewBox="0 0 40 40" fill="none">
                <circle cx="20" cy="20" r="17" stroke="white" strokeWidth="3"/>
                <path d="M12 20L17 25L28 14" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <h1 className="text-white text-[28px] font-bold mb-3">审批通过</h1>
            <div className="flex items-baseline gap-1 mb-2">
              <span className="text-white/80 text-base">借款金额</span>
              <span className="text-white text-[36px] font-bold mx-1">¥3,000</span>
              <span className="text-white/80 text-base">元</span>
            </div>
            <p className="text-white/70 text-[13px] text-center px-4">预计30分钟内到账，具体以短信通知为准</p>
          </div>
        </div>

        {/* 内容区域 */}
        <div className="px-4 -mt-16 space-y-4">

          {/* 审批进度卡片 - 全部完成 */}
          <div className="bg-white rounded-2xl shadow-[0px_4px_20px_rgba(0,0,0,0.08)] px-5 pt-6 pb-5">
            <div className="space-y-0">

              {/* 步骤1：提交申请 */}
              <div className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 bg-[#165dff] rounded-full flex items-center justify-center flex-shrink-0 border-2 border-[#165dff]">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                      <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="M9 12L11 14L15 10" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <div className="w-[2px] flex-1 min-h-[32px] bg-[#165dff]/30 my-1" />
                </div>
                <div className="flex-1 pb-5">
                  <div className="flex justify-between items-center mb-0.5">
                    <span className="text-[#1d2129] text-[15px] font-semibold">提交申请</span>
                    <span className="text-[#165dff] text-[13px]">已完成</span>
                  </div>
                  <p className="text-[#86909c] text-[13px]">申请已提交成功</p>
                </div>
              </div>

              {/* 步骤2：审批完成 */}
              <div className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 bg-[#165dff] rounded-full flex items-center justify-center flex-shrink-0 border-2 border-[#165dff]">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                      <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="M9 12L11 14L15 10" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <div className="w-[2px] flex-1 min-h-[32px] bg-[#165dff]/30 my-1" />
                </div>
                <div className="flex-1 pb-5">
                  <div className="flex justify-between items-center mb-0.5">
                    <span className="text-[#1d2129] text-[15px] font-semibold">审批完成</span>
                    <span className="text-[#165dff] text-[13px]">已完成</span>
                  </div>
                  <p className="text-[#86909c] text-[13px]">资质审核已通过</p>
                </div>
              </div>

              {/* 步骤3：准备放款 */}
              <div className="flex gap-4">
                <div className="w-10 h-10 bg-[#165dff] rounded-full flex items-center justify-center flex-shrink-0 border-2 border-[#165dff]">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M15.0006 2.00007H6.00022C5.46977 2.00007 4.96104 2.2108 4.58596 2.58588C4.21087 2.96097 4.00015 3.46969 4.00015 4.00015V20.0007C4.00015 20.5312 4.21087 21.0399 4.58596 21.415C4.96104 21.7901 5.46977 22.0008 6.00022 22.0008H18.0007C18.5311 22.0008 19.0398 21.7901 19.4149 21.415C19.79 21.0399 20.0007 20.5312 20.0007 20.0007V7.00026L15.0006 2.00007Z" stroke="white" strokeWidth="1.99993" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M14 2V6.00014C14 6.5306 14.2107 7.03932 14.5858 7.41441C14.9609 7.7895 15.4696 8.00022 16 8.00022H20.0002" stroke="white" strokeWidth="1.99993" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center mb-0.5">
                    <span className="text-[#1d2129] text-[15px] font-semibold">准备放款</span>
                    <span className="text-[#165dff] text-[13px]">已完成</span>
                  </div>
                  <p className="text-[#86909c] text-[13px]">资金将在30分钟内到账</p>
                </div>
              </div>

            </div>
          </div>

          {/* 温馨提示卡片 */}
          <div className="bg-[#fffbf0] rounded-2xl border border-[#ffe8b8] p-5">
            <div className="flex gap-3">
              <div className="w-10 h-10 bg-gradient-to-br from-[#fbaf19] to-[#ff9500] rounded-xl flex items-center justify-center flex-shrink-0">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                  <circle cx="12" cy="12" r="10" stroke="white" strokeWidth="2"/>
                  <path d="M12 8V12" stroke="white" strokeWidth="2" strokeLinecap="round"/>
                  <circle cx="12" cy="16" r="1" fill="white"/>
                </svg>
              </div>
              <div>
                <h4 className="text-[#8b4513] text-[13px] font-semibold mb-1">温馨提示</h4>
                <p className="text-[#8b4513] text-[13px] leading-relaxed">
                  您已成功开通惠选卡，放款完成后，您可自主领取并生效对应的权益。
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* 底部按钮 */}
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[440px] bg-white/95 backdrop-blur-sm px-5 py-4 border-t border-[#f2f3f5]">
        <button
          onClick={() => navigate("/confirm-repayment")}
          className="w-full h-14 bg-gradient-to-r from-[#165dff] to-[#4d8fff] rounded-full text-white text-[17px] font-semibold shadow-[0px_8px_24px_rgba(22,93,255,0.35)] active:opacity-90 transition-opacity"
        >
          立即生效权益
        </button>
      </div>
    </MobileLayout>
  );
}
