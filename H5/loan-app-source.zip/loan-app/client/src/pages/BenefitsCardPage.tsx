/**
 * 惠选卡服务详情页
 * 设计风格：蓝色渐变顶部卡片，白色服务特色，权益Tab切换，温馨提示
 */
import { useState } from "react";
import { useLocation } from "wouter";
import MobileLayout from "@/components/MobileLayout";
import {
  BackArrow,
  CheckBlueIcon,
  CardIcon,
  TvIcon,
  CarIcon,
  LifeIcon,
  ShopIcon,
} from "@/components/Icons";

const TABS = [
  { label: "影音会员", Icon: TvIcon },
  { label: "出行服务", Icon: CarIcon },
  { label: "生活服务", Icon: LifeIcon },
  { label: "日常购物", Icon: ShopIcon },
];

type BenefitItem = { discount: string; title: string; desc: string; original: string; save: string };
const BENEFITS_DATA: Record<number, BenefitItem[]> = {
  0: [
    {
      discount: "5折",
      title: "每月4选1影视VIP会员",
      desc: "腾讯视频、优酷会员、爱奇艺、芒果TV任选其一\n有效期30天/次",
      original: "30元",
      save: "省15元",
    },
    {
      discount: "4.5折",
      title: "每月2选1音乐VIP会员",
      desc: "QQ音乐豪华绿钻、网易云音乐黑胶VIP任选\n有效期30天/次",
      original: "29元",
      save: "省11元",
    },
  ],
  1: [
    {
      discount: "6折",
      title: "滴滴出行优惠券",
      desc: "每月10张滴滴出行优惠券\n有效期30天/次",
      original: "50元",
      save: "省20元",
    },
    {
      discount: "7折",
      title: "高铁/机票优惠",
      desc: "每月享受高铁/机票折扣\n有效期30天/次",
      original: "100元",
      save: "省30元",
    },
  ],
  2: [
    {
      discount: "5折",
      title: "美团外卖红包",
      desc: "每月20张外卖红包\n有效期30天/次",
      original: "40元",
      save: "省20元",
    },
    {
      discount: "6折",
      title: "超市购物优惠",
      desc: "每月享受超市购物折扣\n有效期30天/次",
      original: "60元",
      save: "省24元",
    },
  ],
  3: [
    {
      discount: "8折",
      title: "京东购物券",
      desc: "每月5张京东购物券\n有效期30天/次",
      original: "50元",
      save: "省10元",
    },
    {
      discount: "7折",
      title: "淘宝/天猫优惠",
      desc: "每月享受淘宝/天猫折扣\n有效期30天/次",
      original: "80元",
      save: "省24元",
    },
  ],
};

const FEATURES = [
  {
    title: "先享后付，无压力消费",
    desc: "支持多种消费场景，先享受服务后付款，让您的消费更灵活",
  },
  {
    title: "费用预估¥100/月，共3期",
    desc: "分期付款，减轻还款压力，每月仅需100元，轻松管理财务",
  },
  {
    title: "匹配优质权益，不成功不收费",
    desc: "智能匹配最适合您的金融产品，申请不成功不收取任何费用",
  },
];

const TIPS = [
  "权益服务费基于惠聚会员服务收取，包含影音娱乐、购物出行、生活服务、放款通道匹配等特权。",
  "本费用为互联网增值服务，独立于借款，非贷款利率、保障金或违约金。",
  "您充分知晓服务内容，先享后付模式下系统将从您指定银行卡扣费。",
];

export default function BenefitsCardPage() {
  const [, navigate] = useLocation();
  const [activeTab, setActiveTab] = useState(0);

  const benefits = BENEFITS_DATA[activeTab];

  return (
    <MobileLayout>
      {/* 顶部导航 */}
      <div className="sticky top-0 z-10 bg-white border-b border-gray-100 h-[54px] flex items-center px-5">
        <button onClick={() => navigate("/approval-pending")} className="absolute left-5">
          <BackArrow className="w-6 h-6" color="#1d2129" />
        </button>
        <h1 className="w-full text-center text-[#1d2129] text-[17px] font-semibold">服务详情</h1>
      </div>

      <div className="flex-1 overflow-y-auto bg-[#f7f8fa] pb-24">
        <div className="px-4 pt-4 space-y-4">

          {/* 惠选卡顶部卡片 */}
          <div className="bg-gradient-to-br from-[#165dff] via-[#1a65ff] to-[#4d8fff] rounded-2xl p-5 overflow-hidden relative shadow-[0px_8px_24px_rgba(22,93,255,0.25)]">
            <div className="absolute w-32 h-32 right-[-10px] top-[-10px] bg-white/10 rounded-full blur-3xl" />
            <div className="relative">
              <div className="flex items-center gap-2 mb-1">
                <h2 className="text-white text-xl font-bold">惠选卡</h2>
                <span className="bg-white/20 text-white text-[11px] px-2 py-0.5 rounded-full">精选权益</span>
              </div>
              <p className="text-white/70 text-[13px] mb-4">精选热门权益 · 享超值立减</p>
              <div className="bg-white/15 rounded-xl p-4 flex items-center justify-between">
                <div>
                  <p className="text-white/70 text-xs mb-1">服务现价</p>
                  <div className="flex items-baseline gap-0.5">
                    <span className="text-[#ffd700] text-[32px] font-bold leading-none">300</span>
                    <span className="text-[#ffd700] text-base font-medium ml-0.5">元</span>
                  </div>
                </div>
                <button
                  onClick={() => navigate("/approval-result")}
                  className="bg-gradient-to-br from-[#fbaf19] to-[#ff9500] rounded-xl px-5 py-3 text-white text-[13px] font-semibold shadow-lg"
                >
                  立即开通<br />享千元权益
                </button>
              </div>
            </div>
          </div>

          {/* 服务特色 */}
          <div className="bg-white rounded-2xl shadow-sm border border-[#f2f3f5] p-5">
            <h3 className="text-[#1d2129] text-[15px] font-semibold mb-4">服务特色</h3>
            <div className="space-y-4">
              {FEATURES.map((item, i) => (
                <div key={i} className="flex gap-3">
                  <div className="w-5 h-5 mt-0.5 flex-shrink-0 bg-[#165dff]/10 rounded-full flex items-center justify-center">
                    <CheckBlueIcon className="w-3 h-3" />
                  </div>
                  <div>
                    <p className="text-[#1d2129] text-[13px] font-semibold mb-0.5">{item.title}</p>
                    <p className="text-[#86909c] text-[12px] leading-relaxed">{item.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 专属权益 */}
          <div className="bg-white rounded-2xl shadow-sm border border-[#f2f3f5] p-5">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-[#1d2129] text-[15px] font-semibold">专属权益</h3>
              <div className="flex items-baseline gap-1">
                <span className="text-[#86909c] text-xs">立省</span>
                <span className="text-[#ff6b00] text-lg font-bold">448</span>
                <span className="text-[#ff6b00] text-xs font-medium">元</span>
              </div>
            </div>

            {/* Tab切换 */}
            <div className="flex gap-0 mb-4 border-b border-[#f2f3f5]">
              {TABS.map((tab, i) => {
                const { Icon } = tab;
                return (
                  <button
                    key={i}
                    onClick={() => setActiveTab(i)}
                    className={`flex-1 flex flex-col items-center gap-1.5 pb-3 pt-1 transition-all ${
                      activeTab === i ? "border-b-2 border-[#165dff]" : ""
                    }`}
                  >
                    <Icon className="w-6 h-6" active={activeTab === i} />
                    <span className={`text-[11px] ${activeTab === i ? "text-[#165dff] font-semibold" : "text-[#86909c]"}`}>
                      {tab.label}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* 权益卡片列表 */}
            <div className="space-y-3">
              {benefits.map((b, i) => (
                <div key={i} className="flex gap-3 bg-[#f7f8fa] rounded-xl p-3">
                  <div className="w-12 h-12 bg-[#fff3e0] rounded-lg flex flex-col items-center justify-center flex-shrink-0">
                    <span className="text-[#ff6b00] text-[16px] font-bold leading-none">{b.discount}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between mb-1 gap-2">
                      <p className="text-[#1d2129] text-[13px] font-semibold">{b.title}</p>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        <span className="text-[#c9cdd4] text-[11px] line-through">{b.original}</span>
                        <span className="bg-[#ff6b00]/10 text-[#ff6b00] text-[10px] font-medium px-1.5 py-0.5 rounded">{b.save}</span>
                      </div>
                    </div>
                    <p className="text-[#86909c] text-[11px] leading-relaxed whitespace-pre-line">{b.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* 温馨提示 */}
          <div className="bg-white rounded-2xl shadow-sm border border-[#f2f3f5] p-5">
            <h3 className="text-[#1d2129] text-[15px] font-semibold mb-3">温馨提示</h3>
            <div className="space-y-2">
              {TIPS.map((tip, i) => (
                <div key={i} className="flex gap-2">
                  <span className="text-[#86909c] text-xs mt-0.5 flex-shrink-0">•</span>
                  <p className="text-[#86909c] text-[12px] leading-relaxed">{tip}</p>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>

      {/* 底部按钮 */}
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[440px] bg-white/95 backdrop-blur-sm px-5 py-4 border-t border-[#f2f3f5]">
        <button
          onClick={() => navigate("/approval-result")}
          className="w-full h-14 bg-gradient-to-r from-[#165dff] to-[#4d8fff] rounded-full text-white text-[17px] font-semibold shadow-[0px_8px_24px_rgba(22,93,255,0.35)] active:opacity-90 transition-opacity"
        >
          立即开通
        </button>
      </div>
    </MobileLayout>
  );
}
