/**
 * 用信审批中页 - 借款审批进行中状态
 * 设计风格：蓝色渐变顶部，白色进度卡片，米黄色惠选卡广告
 * 步骤图标：蓝色圆形，内部白色图标
 */
import { useLocation } from "wouter";
import MobileLayout from "@/components/MobileLayout";

export default function ApprovalPendingPage() {
  const [, navigate] = useLocation();

  return (
    <MobileLayout>
      <div className="flex-1 overflow-y-auto bg-[#f7f8fa] pb-36">

        {/* 蓝色渐变顶部区域 */}
        <div className="bg-gradient-to-b from-[#165dff] to-[#3d7aff] px-5 pt-14 pb-28 overflow-hidden relative">
          <div className="absolute w-48 h-48 right-[-30px] top-[-20px] bg-white/10 rounded-full" />
          <div className="absolute w-36 h-36 left-[-15px] bottom-[-10px] bg-white/10 rounded-full" />
          <div className="relative flex flex-col items-center">
            {/* 时钟图标 */}
            <div className="w-[72px] h-[72px] bg-white/25 rounded-full flex items-center justify-center mb-5">
              <svg width="36" height="36" viewBox="0 0 40 40" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M20 36.6666C29.2048 36.6666 36.6667 29.2047 36.6667 20C36.6667 10.7952 29.2048 3.33333 20 3.33333C10.7953 3.33333 3.33337 10.7952 3.33337 20C3.33337 29.2047 10.7953 36.6666 20 36.6666Z" stroke="white" strokeWidth="3.33321" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M20 10V20L26.6667 23.3333" stroke="white" strokeWidth="3.33321" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <h1 className="text-white text-[28px] font-bold mb-2">借款审批中</h1>
            <p className="text-white/80 text-[14px] text-center px-4">请您耐心等待，具体审批结果以短信通知为准…</p>
          </div>
        </div>

        {/* 内容区域（与蓝色背景重叠） */}
        <div className="px-4 -mt-16 space-y-4">

          {/* 审批进度卡片 */}
          <div className="bg-white rounded-2xl shadow-[0px_4px_20px_rgba(0,0,0,0.08)] px-5 pt-6 pb-5">
            <div className="space-y-0">

              {/* 步骤1：提交申请 - 已完成 */}
              <div className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 bg-[#165dff] rounded-full flex items-center justify-center flex-shrink-0 border-2 border-[#165dff]">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                      <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="M9 12L11 14L15 10" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <div className="w-[2px] flex-1 min-h-[32px] bg-[#165dff]/30 my-1" />
                </div>
                <div className="flex-1 pb-5">
                  <div className="flex justify-between items-center mb-0.5">
                    <span className="text-[#1d2129] text-[15px] font-semibold">提交申请</span>
                    <span className="text-[#165dff] text-[13px]">已完成</span>
                  </div>
                  <p className="text-[#86909c] text-[13px]">申请已提交成功</p>
                </div>
              </div>

              {/* 步骤2：审批中 - 进行中 */}
              <div className="flex gap-4">
                <div className="flex flex-col items-center">
                  <div className="w-10 h-10 bg-[#165dff]/70 rounded-full flex items-center justify-center flex-shrink-0 border-2 border-[#165dff]/70">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                      <path d="M12 22C17.5228 22 22 17.5228 22 12C22 6.47715 17.5228 2 12 2C6.47715 2 2 6.47715 2 12C2 17.5228 6.47715 22 12 22Z" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                      <path d="M12 6V12.0002L16.0002 14.0003" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </div>
                  <div className="w-[2px] flex-1 min-h-[32px] bg-[#e5e6eb] my-1" />
                </div>
                <div className="flex-1 pb-5">
                  <div className="flex justify-between items-center mb-0.5">
                    <span className="text-[#1d2129] text-[15px] font-semibold">审批中</span>
                    <span className="text-[#165dff] text-[13px]">进行中</span>
                  </div>
                  <p className="text-[#86909c] text-[13px]">正在进行资质审核...</p>
                </div>
              </div>

              {/* 步骤3：等待放款 - 待审批 */}
              <div className="flex gap-4">
                <div className="w-10 h-10 bg-[#f2f3f5] rounded-full flex items-center justify-center flex-shrink-0 border-2 border-[#e5e6eb]">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                    <path d="M15.0006 2.00007H6.00022C5.46977 2.00007 4.96104 2.2108 4.58596 2.58588C4.21087 2.96097 4.00015 3.46969 4.00015 4.00015V20.0007C4.00015 20.5312 4.21087 21.0399 4.58596 21.415C4.96104 21.7901 5.46977 22.0008 6.00022 22.0008H18.0007C18.5311 22.0008 19.0398 21.7901 19.4149 21.415C19.79 21.0399 20.0007 20.5312 20.0007 20.0007V7.00026L15.0006 2.00007Z" stroke="#86909C" strokeWidth="1.99993" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M14 2V6.00014C14 6.5306 14.2107 7.03932 14.5858 7.41441C14.9609 7.7895 15.4696 8.00022 16 8.00022H20.0002" stroke="#86909C" strokeWidth="1.99993" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <div className="flex-1">
                  <div className="flex justify-between items-center mb-0.5">
                    <span className="text-[#86909c] text-[15px] font-semibold">等待放款</span>
                    <span className="text-[#86909c] text-[13px]">待审批</span>
                  </div>
                  <p className="text-[#c9cdd4] text-[13px]">审批通过后即可放款</p>
                </div>
              </div>

            </div>
          </div>

          {/* 惠选卡广告卡片 */}
          <div
            className="relative bg-[#fffbf0] rounded-2xl border border-[#ffe8b8] overflow-hidden cursor-pointer"
            onClick={() => navigate("/benefits-card")}
          >
            <div className="relative p-5">
              {/* 标题行 */}
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 bg-gradient-to-br from-[#fbaf19] to-[#ff9500] rounded-[10px] flex items-center justify-center">
                    <svg width="14" height="11" viewBox="0 0 14 11" fill="none">
                      <path d="M12.375 0H1.375C0.611875 0 0.00687499 0.611875 0.00687499 1.375L0 9.625C0 10.3881 0.611875 11 1.375 11H12.375C13.1381 11 13.75 10.3881 13.75 9.625V1.375C13.75 0.611875 13.1381 0 12.375 0ZM12.375 9.625H1.375V5.5H12.375V9.625ZM12.375 2.75H1.375V1.375H12.375V2.75Z" fill="white"/>
                    </svg>
                  </div>
                  <span className="text-[#333] text-[15px] font-semibold">惠选卡</span>
                  <div className="bg-white/80 rounded px-1.5 py-0.5 border border-[#e5e6eb]">
                    <span className="text-[#999] text-[10px]">广告</span>
                  </div>
                </div>
                <button
                  className="flex items-center gap-1"
                  onClick={(e) => { e.stopPropagation(); navigate("/benefits-card"); }}
                >
                  <span className="text-[#ff6b00] text-[13px] font-medium">权益详情</span>
                  <svg width="5" height="9" viewBox="0 0 5 9" fill="none">
                    <path d="M0.624951 8.12518L4.37503 4.3751L0.624951 0.625016" stroke="#FF6B00" strokeWidth="1.16613" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </button>
              </div>

              {/* 服务特色 */}
              <div className="mb-4">
                <h4 className="text-[#333] text-[13px] font-semibold mb-3">服务特色</h4>
                <div className="space-y-2.5">
                  {[
                    "热门影音会员，出行礼包",
                    "享最高300元优惠",
                    "专属优先通道，不成功不收费",
                  ].map((text, i) => (
                    <div key={i} className="flex items-center gap-2.5">
                      <div className="w-5 h-5 flex items-center justify-center flex-shrink-0">
                        <svg width="9" height="7" viewBox="0 0 9 7" fill="none">
                          <path d="M0.681843 3.95454L2.86366 6.13636L8.31821 0.68181" stroke="#165DFF" strokeWidth="1.24995" strokeLinecap="round" strokeLinejoin="round"/>
                        </svg>
                      </div>
                      <span className="text-[#333] text-[13px]">{text}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* 底部协议 */}
              <div className="border-t border-[#ffe8b8]/60 pt-3">
                <p className="text-[#999] text-[11px] leading-relaxed">
                  专享价¥300, 开通即同意
                  <span className="text-[#165dff]">《用户服务协议》</span>
                  <span className="text-[#165dff]">《隐私条款声明》</span>
                  <span className="text-[#165dff]">《委托扣款协议》</span>
                  <span className="text-[#165dff]">《权益服务协议》</span>
                </p>
              </div>
            </div>
          </div>

        </div>
      </div>

      {/* 底部按钮区域 */}
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[440px] bg-white/95 backdrop-blur-sm px-5 pt-4 pb-8 border-t border-[#f2f3f5]">
        <button
          onClick={() => navigate("/benefits-card")}
          className="w-full h-14 bg-gradient-to-r from-[#165dff] to-[#4d8fff] rounded-full text-white text-[17px] font-semibold shadow-[0px_8px_24px_rgba(22,93,255,0.35)] mb-3 active:opacity-90 transition-opacity"
        >
          开通服务，极速借款
        </button>
        <button
          onClick={() => navigate("/approval-result")}
          className="w-full text-center text-[#86909c] text-[14px]"
        >
          放弃优惠，继续等待
        </button>
      </div>
    </MobileLayout>
  );
}
