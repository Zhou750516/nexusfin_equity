/**
 * 还款成功页
 * 设计风格：蓝色渐变顶部，还款详情卡片（日历/卡片/下降箭头图标），温馨提示，返回首页
 */
import { useLocation } from "wouter";
import MobileLayout from "@/components/MobileLayout";

const TIPS = [
  "还款金额已从您的银行卡扣除，请注意查收银行通知",
  "提前还款后，您的信用额度将即时恢复",
  '如需查看还款记录，可前往"我的"-"账单明细"',
  "若有任何疑问，请联系客服：400-888-8888",
];

export default function RepaymentSuccessPage() {
  const [, navigate] = useLocation();

  return (
    <MobileLayout>
      <div className="flex-1 overflow-y-auto bg-[#f7f8fa] pb-24">

        {/* 蓝色渐变顶部 */}
        <div className="bg-gradient-to-b from-[#165dff] to-[#3d7aff] px-5 pt-14 pb-28 overflow-hidden relative">
          <div className="absolute w-48 h-48 right-[-30px] top-[-20px] bg-white/10 rounded-full" />
          <div className="absolute w-36 h-36 left-[-15px] bottom-[-10px] bg-white/10 rounded-full" />
          <div className="relative flex flex-col items-center">
            {/* 成功图标 */}
            <div className="w-[72px] h-[72px] bg-white/25 rounded-full flex items-center justify-center mb-5">
              <svg width="36" height="36" viewBox="0 0 40 40" fill="none">
                <circle cx="20" cy="20" r="17" stroke="white" strokeWidth="3"/>
                <path d="M12 20L17 25L28 14" stroke="white" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <h1 className="text-white text-[28px] font-bold mb-3">还款成功</h1>
            <div className="flex items-baseline gap-1">
              <span className="text-white/80 text-base">还款金额</span>
              <span className="text-white text-[36px] font-bold mx-1">¥1018.50</span>
              <span className="text-white/80 text-base">元</span>
            </div>
          </div>
        </div>

        {/* 内容区域 */}
        <div className="px-4 -mt-16 space-y-4">

          {/* 还款详情卡片 */}
          <div className="bg-white rounded-2xl shadow-[0px_4px_20px_rgba(0,0,0,0.08)] px-5 pt-5 pb-5">
            <h3 className="text-[#1d2129] text-[15px] font-bold mb-4">还款详情</h3>
            <div className="border-t border-[#f2f3f5] pt-4 space-y-5">

              {/* 还款时间 */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#f0f4ff] rounded-full flex items-center justify-center flex-shrink-0">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                    <rect x="3" y="4" width="18" height="18" rx="2" stroke="#165DFF" strokeWidth="1.5"/>
                    <path d="M3 9H21" stroke="#165DFF" strokeWidth="1.5"/>
                    <path d="M8 2V6M16 2V6" stroke="#165DFF" strokeWidth="1.5" strokeLinecap="round"/>
                  </svg>
                </div>
                <div>
                  <p className="text-[#86909c] text-[12px] mb-0.5">还款时间</p>
                  <p className="text-[#1d2129] text-[15px] font-semibold">2026年3月19日 14:32</p>
                </div>
              </div>

              {/* 还款银行卡 */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#f0f4ff] rounded-full flex items-center justify-center flex-shrink-0">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                    <rect x="2" y="5" width="20" height="14" rx="2" stroke="#165DFF" strokeWidth="1.5"/>
                    <path d="M2 10H22" stroke="#165DFF" strokeWidth="1.5"/>
                    <rect x="5" y="13" width="4" height="2" rx="1" fill="#165DFF"/>
                  </svg>
                </div>
                <div>
                  <p className="text-[#86909c] text-[12px] mb-0.5">还款银行卡</p>
                  <p className="text-[#1d2129] text-[15px] font-semibold">招商银行 (8648)</p>
                </div>
              </div>

              {/* 节省利息 */}
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-[#f0fff4] rounded-full flex items-center justify-center flex-shrink-0">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none">
                    <path d="M3 7L9 13L13 9L21 17" stroke="#22C55E" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    <path d="M17 17H21V13" stroke="#22C55E" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <div>
                  <p className="text-[#86909c] text-[12px] mb-0.5">节省利息</p>
                  <p className="text-[#22c55e] text-[15px] font-semibold">¥26.50</p>
                </div>
              </div>

            </div>
          </div>

          {/* 温馨提示 */}
          <div className="bg-white rounded-2xl shadow-sm border border-[#f2f3f5] p-5">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-1 h-5 bg-[#165dff] rounded-full" />
              <h3 className="text-[#1d2129] text-[15px] font-semibold">温馨提示</h3>
            </div>
            <div className="space-y-2">
              {TIPS.map((tip, i) => (
                <div key={i} className="flex gap-2">
                  <span className="text-[#86909c] text-[13px] mt-0.5 flex-shrink-0">•</span>
                  <p className="text-[#86909c] text-[13px] leading-relaxed">{tip}</p>
                </div>
              ))}
            </div>
          </div>

        </div>
      </div>

      {/* 底部按钮 */}
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[440px] bg-white/95 backdrop-blur-sm px-5 py-4 border-t border-[#f2f3f5]">
        <button
          onClick={() => navigate("/")}
          className="w-full h-14 bg-gradient-to-r from-[#165dff] to-[#4d8fff] rounded-full text-white text-[17px] font-semibold shadow-[0px_8px_24px_rgba(22,93,255,0.35)] active:opacity-90 transition-opacity"
        >
          返回首页
        </button>
      </div>
    </MobileLayout>
  );
}
