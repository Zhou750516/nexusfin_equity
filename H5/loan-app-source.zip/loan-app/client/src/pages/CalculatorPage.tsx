/**
 * 试算页 - 借款金额选择与费用计算
 * 设计风格：蓝色渐变主题，白色卡片，移动端优先
 * 主色：#165dff，强调色：#ff6b00，背景：#f7f8fa
 */
import { useState } from "react";
import { useLocation } from "wouter";
import MobileLayout from "@/components/MobileLayout";

const TERM_OPTIONS = [
  { label: "1期", value: 1 },
  { label: "3期", value: 3 },
  { label: "6期", value: 6 },
];

const REPAYMENT_DATA: Record<number, { totalFee: string; firstDate: string; firstAmount: string; monthlyAmount: string }> = {
  1: { totalFee: "¥45.00", firstDate: "5月07日", firstAmount: "¥3045.00", monthlyAmount: "¥3045.00" },
  3: { totalFee: "¥135.00", firstDate: "5月07日", firstAmount: "¥1045.00", monthlyAmount: "¥1045.00" },
  6: { totalFee: "¥270.00", firstDate: "5月07日", firstAmount: "¥545.00", monthlyAmount: "¥545.00" },
};

export default function CalculatorPage() {
  const [, navigate] = useLocation();
  const [selectedTerm, setSelectedTerm] = useState(3);
  const [agreed, setAgreed] = useState(false);
  const [expanded, setExpanded] = useState(false);

  const repayment = REPAYMENT_DATA[selectedTerm];

  return (
    <MobileLayout>
      {/* 顶部导航栏 */}
      <div className="bg-white h-[54px] flex items-center px-5 border-b border-[#f2f3f5]">
        <button
          className="flex items-center gap-1 text-[#1d2129] text-[17px] font-medium"
          onClick={() => history.back()}
        >
          <svg width="8" height="14" viewBox="0 0 8 14" fill="none">
            <path d="M7 1L1 7L7 13" stroke="#1d2129" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
          <span className="ml-1">返回</span>
        </button>
      </div>

      {/* 页面内容 */}
      <div className="flex-1 overflow-y-auto bg-[#f7f8fa] pb-24">
        <div className="px-4 pt-4 space-y-3">

          {/* 借款金额卡片 */}
          <div className="relative bg-gradient-to-br from-[#165dff] via-[#1a65ff] to-[#4d8fff] rounded-2xl shadow-[0px_8px_24px_rgba(22,93,255,0.25)] overflow-hidden">
            <div className="absolute w-32 h-32 right-[-10px] top-[-10px] bg-white/10 rounded-full blur-3xl" />
            <div className="relative px-6 pt-5 pb-5">
              <p className="text-white/80 text-[13px] font-normal mb-3">借款金额</p>
              <div className="flex items-end gap-2 border-b border-white/30 pb-3 mb-3">
                <span className="text-white text-[22px] font-medium leading-none mb-1">¥</span>
                <span className="text-white text-[56px] font-bold leading-none">3000</span>
                <button className="ml-auto text-white/70 text-[13px] font-normal pb-1">修改金额</button>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-1.5 h-1.5 bg-white/50 rounded-full" />
                <span className="text-white/70 text-[13px]">可选金额范围 ¥100 - ¥5000</span>
              </div>
            </div>
          </div>

          {/* 借多久 */}
          <div className="bg-white rounded-2xl border border-[#f2f3f5] px-5 pt-5 pb-4">
            <h3 className="text-[#1d2129] text-[15px] font-semibold mb-4">借多久</h3>
            <div className="flex gap-3">
              {TERM_OPTIONS.map((opt) => (
                <button
                  key={opt.value}
                  onClick={() => setSelectedTerm(opt.value)}
                  className={`flex-1 h-11 rounded-xl text-[15px] font-medium transition-all ${
                    selectedTerm === opt.value
                      ? "bg-[#f0f4ff] text-[#165dff] border border-[#165dff]"
                      : "bg-white text-[#4e5969] border border-[#e5e6eb]"
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* 怎么还 */}
          <div className="bg-white rounded-2xl border border-[#f2f3f5] px-5 pt-5 pb-5">
            <h3 className="text-[#1d2129] text-[17px] font-bold mb-4">怎么还</h3>
            {/* 总息费 */}
            <div className="flex justify-between items-center py-4 border-b border-[#f2f3f5]">
              <span className="text-[#4e5969] text-[15px]">总息费</span>
              <span className="text-[#ff6b00] text-[20px] font-bold">{repayment.totalFee}</span>
            </div>
            {/* 首期还款 */}
            <div className="flex justify-between items-center pt-4">
              <span className="text-[#4e5969] text-[15px]">首期还款</span>
              <div className="flex items-center gap-3">
                <div className="text-right">
                  <p className="text-[#86909c] text-[13px]">{repayment.firstDate}</p>
                  <p className="text-[#1d2129] text-[17px] font-bold">{repayment.firstAmount}</p>
                </div>
                <button
                  onClick={() => setExpanded(!expanded)}
                  className="text-[#165dff] text-[13px] font-medium"
                >
                  {expanded ? "收起" : "展开"}
                </button>
              </div>
            </div>
            {/* 展开的还款计划 */}
            {expanded && (
              <div className="mt-4 space-y-3 border-t border-[#f2f3f5] pt-4">
                {Array.from({ length: selectedTerm }, (_, i) => (
                  <div key={i} className="flex justify-between items-center">
                    <span className="text-[#86909c] text-[13px]">第{i + 1}期</span>
                    <div className="text-right">
                      <p className="text-[#86909c] text-[12px]">{`${5 + i}月07日`}</p>
                      <p className="text-[#1d2129] text-[14px] font-medium">{repayment.monthlyAmount}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* 收款账户 */}
          <div className="bg-white rounded-2xl border border-[#f2f3f5] px-5 py-4">
            <div className="flex justify-between items-center">
              <span className="text-[#4e5969] text-[15px]">收款账户</span>
              <span className="text-[#1d2129] text-[15px] font-medium">招商银行 8648</span>
            </div>
          </div>

          {/* 放款资方 */}
          <div className="bg-white rounded-2xl border border-[#f2f3f5] px-5 py-4">
            <div className="flex justify-between items-center">
              <span className="text-[#4e5969] text-[15px]">放款资方</span>
              <span className="text-[#1d2129] text-[15px] font-medium">XX商业银行</span>
            </div>
          </div>

          {/* 综合年化利率 */}
          <div className="bg-[#f7f8fa] rounded-2xl border border-[#e5e6eb] px-5 py-4">
            <div className="flex justify-between items-center mb-1">
              <span className="text-[#86909c] text-[13px]">综合年化利率</span>
              <span className="text-[#4e5969] text-[13px] font-medium">18.0%</span>
            </div>
            <p className="text-[#86909c] text-[12px]">除借款利息外，无其他任何费用</p>
          </div>

          {/* 协议勾选 */}
          <div className="flex items-start gap-3 px-1 py-2">
            <button
              onClick={() => setAgreed(!agreed)}
              className={`mt-0.5 w-[18px] h-[18px] rounded flex-shrink-0 transition-all ${
                agreed
                  ? "bg-[#165dff] border border-[#165dff]"
                  : "bg-white border border-[#c9cdd4]"
              } flex items-center justify-center`}
            >
              {agreed && (
                <svg width="10" height="8" viewBox="0 0 10 8" fill="none">
                  <path d="M1 4L3.5 6.5L9 1" stroke="white" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              )}
            </button>
            <p className="text-[#4e5969] text-[13px] leading-relaxed">
              我已阅读并同意{" "}
              <span className="text-[#165dff]">《用户协议》</span>、
              <span className="text-[#165dff]">《借款协议》</span>、
              <span className="text-[#165dff]">《隐私声明》</span>
              {" "}等相关条款
            </p>
          </div>
        </div>
      </div>

      {/* 底部按钮 */}
      <div className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[440px] bg-white/95 backdrop-blur-sm px-5 py-4 border-t border-[#f2f3f5]">
        <button
          onClick={() => navigate("/approval-pending")}
          className="w-full h-14 bg-gradient-to-r from-[#165dff] to-[#4d8fff] rounded-full text-white text-[17px] font-semibold shadow-[0px_8px_24px_rgba(22,93,255,0.35)] active:opacity-90 transition-opacity"
        >
          确认借款
        </button>
      </div>
    </MobileLayout>
  );
}
