import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import CalculatorPage from "./pages/CalculatorPage";
import ApprovalPendingPage from "./pages/ApprovalPendingPage";
import BenefitsCardPage from "./pages/BenefitsCardPage";
import ApprovalResultPage from "./pages/ApprovalResultPage";
import ConfirmRepaymentPage from "./pages/ConfirmRepaymentPage";
import RepaymentSuccessPage from "./pages/RepaymentSuccessPage";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={CalculatorPage} />
      <Route path={"/approval-pending"} component={ApprovalPendingPage} />
      <Route path={"/benefits-card"} component={BenefitsCardPage} />
      <Route path={"/approval-result"} component={ApprovalResultPage} />
      <Route path={"/confirm-repayment"} component={ConfirmRepaymentPage} />
      <Route path={"/repayment-success"} component={RepaymentSuccessPage} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
